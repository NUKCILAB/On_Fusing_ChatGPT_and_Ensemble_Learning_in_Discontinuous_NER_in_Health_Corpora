README for ShARe/CLEF eHealth 2013 Evaluation Lab PhysionetWorks Project

# last updated Saturday, 27 February 2013 4:00 pm Pacific time

==========
Task1
==========

DOCUMENTATION
-----------------------------------------------------------
Task1ShAReGuidelines2013.pdf
-----------------------------------------------------------
Guidelines used for annotating disorder mentions in text (boundary detection) and mapping the annotations to Snomed UMLS codes (normalization).


TOOLS

-----------------------------------------------------------
Task1Eval.pl
-----------------------------------------------------------
Perl evaluation script for calculating outcome measures comparing system output to GOLD output. This is the official script for determining system performance.

example:
perl eval.pl -n myrun -r 1 -t 1a -input /Users/wendyc/Desktop/CLEF/Task1TrainSetGOLD199pipe -gold /Users/wendyc/Desktop/CLEF/Task1TrainSetSystem199pipe -a

-----------------------------------------------------------
EvaluationWorkbenchFolder.zip (238 MB)
-----------------------------------------------------------
The Evaluation Workbench for visualizing GOLD annotations and system annotations and for calculating outcome measures.

-----------------------------------------------------------
ehost-14Feb2013.zip
-----------------------------------------------------------
Latest eHost release for annotating text according to the schema used in this project. You can use eHost to view annotations in the GOLD corpus and to annotate additional reports using the same schema, if you plan to use additional annotations. Open one batch of reports at a time (10 reports). If you would like to view the entire training set, use the Evaluation Workbench.

-----------------------------------------------------------
convertFilesToUnixFormat.jar
-----------------------------------------------------------
A java program for converting non-Unix to Unix linefeeds.  The script is a java program based on the flip utility for converting non-Unix to Unix linefeeds (https://ccrma.stanford.edu/~craig/utility/flip/). If you are not using a Unix or MacOS operating system, once you download the datasets, please run the program on the directory containing the corpus of text files to create a new directory with Unix linefeeds:

java -jar convertFilesToUnixFormat.jar <directory containing corpus files> <new directory>

TEXT CORPUS
-----------------------------------------------------------
Task1TrainSetCorpus199.zip
-----------------------------------------------------------
199 Training set text reports stored in a single file. Point the Evaluation Workbench to this file to read in the full training set corpus at once (see intsructions at https://sites.google.com/site/shareclefehealth/evaluation#TOC-Tools-for-Evaluation). If you are going to view the reports and annotations in eHost or Knowtator, you will need to break up the reports and the annotations into smaller matching batches of 10-20 reports each.


GOLD STANDARD ANNOTATIONS
-----------------------------------------------------------
Task1TrainSetGOLD199pipe.zip
-----------------------------------------------------------
Annotations for 199 training set texts in double-pipe-delimited format required by evaluation script and Evaluation Workbench. 
report name || annotation type || cui || char start || char end
08114-027511-DISCHARGE_SUMMARY.txt||Disease_Disorder||c0332799||459||473
If the annotation has a disjoint span (i.e., non-contiguous span), the next part of the span will be appended and separated by double pipes
08114-027511-DISCHARGE_SUMMARY.txt||Disease_Disorder||c0332799||459||473||482||489

-----------------------------------------------------------
Task1TrainSetGOLD199Knowtatorehost.zip
-----------------------------------------------------------
Annotations for 199 training set texts in xml format required to read into Knowtator or eHost. If you are going to view the reports and annotations in eHost or Knowtator, you will need to break up the reports and the annotations into smaller matching batches of 10-20 reports each.




