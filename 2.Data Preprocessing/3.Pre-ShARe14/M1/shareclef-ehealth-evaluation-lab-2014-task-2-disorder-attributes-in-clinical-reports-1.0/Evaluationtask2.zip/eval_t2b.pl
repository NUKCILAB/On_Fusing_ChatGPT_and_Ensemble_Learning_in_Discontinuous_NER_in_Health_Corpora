#!/usr/bin/perl -w
# Parameters:
# -input (prediction directory)
# -gold (goldstandard directory)
# -n (specify name of run)
# -r (specify 1 or 2 for which run)
# -a (optional - include if you used additional annotations)

# Output file: name + run + task + add/noadd (e.g. myrun.1.1a.add)

# Example:
# ./eval_t2b.pl -n test -r 1 -input /home/davidm/Data/CLEF2014/Example -gold /home/davidm/Data/CLEF2014/2014ShAReCLEFeHealthTasks2_training_10Jan2014/2014ShAReCLEFeHealthTask2_training_pipedelimited -a


use strict;

use vars qw (%TF %H @F $i @File $f @FNames %T $t);

use Getopt::Long;

my $add = "noadd";
my $name = "";
my $run = "";
my $input = "";
my $gold = "";
my $error = "# Parameters:\n# -input (prediction file)\n# -gold (goldstandard file)\n# -n (specify name of run)\n# -r (specify 1 or 2 for which run)\n# -a (optional - include if you used additional annotations)\n";


GetOptions ('a' => \$add,
	    'n=s'=>\$name,
	    'r=n'=>\$run,
	    'input=s'=>\$input,
	    'gold=s'=>\$gold	  
    )||die "$error";

if (($name eq "")||($input eq "")||($gold eq "")) {
    die "$error";}
if (($run != 1)&&($run != 2)) {
    die "Incorrect run id\n";}
if ($add eq "1") {
    $add = "add";
}

#target fields
%TF = ("4"=>1,
       "6"=>1,
       "8"=>1,
       "10"=>1,
       "12"=>1,
       "14"=>1,
       "16"=>1,
       "18"=>1,
       "21"=>1
    );

@FNames = split(/\|/,"DD_DocName|DD_Spans|DD_CUI|Norm_NI|Cue_NI|Norm_SC|Cue_SC|Norm_UI|Cue_UI|Norm_CC|Cue_CC|Norm_SV|Cue_SV|Norm_CO|Cue_CO|Norm_GC|Cue_GC|Norm_BL|Cue_BL|Norm_DT|Norm_TE|Cue_TE");

# read predictions and goldstandard
%T = ("Gold"=>$gold,"Pred"=>$input);
undef %H;

foreach $t (keys %T) {
    opendir(D,$T{$t})||die;

    @File = grep /^[^\.].*[^\~]$/,readdir D;
    closedir(D);

    foreach $f (@File) {

	open(I,"$T{$t}/$f")||die "Input file not found: $T{$t}\/$f\n";
	
	while(<I>) {
	    chomp;
	    s /\|\|/\|/g;
	    @F = split(/\|/,$_);
	    for($i = 4;$i<=18;$i+=2) {
		$H{$t}{"$F[0]\-$F[1]\-$F[2]"}{$i} = lc($F[$i]);
	    }
	    $H{$t}{"$F[0]\-$F[1]\-$F[2]"}{21} = lc($F[21]);
	}
	close(I);
    }
}

open(O,">$name")||die "Error: Cannot write file: $name\n";
&task2b_acc;
&task2b_fsc;
close(O);

sub task2b_acc {

    my (%Eval,$id,$field,$ok,$ko,$t);
    my @T = ("strict","relaxed");

    foreach $t (@T) {
	undef %Eval;

	$ok = 0; $ko = 0;
	foreach $id (keys %{$H{Pred}}) {    
	    foreach $field (keys %{$H{Pred}{$id}}) {	
		if ($H{Gold}{$id}{$field} eq $H{Pred}{$id}{$field}) {	    
		    $Eval{$field}{ok}++;
		    $ok++;
		}
		elsif (($t eq "relaxed")&&
		       (&overlap($H{Gold}{$id}{$field},$H{Pred}{$id}{$field}))) {
		    $Eval{$field}{ok}++;
		    $ok++;
		}
		else {
		    $Eval{$field}{ko}++;
		    $ko++;
		}
	    }
	}
	
	$_ = $ok / ($ok + $ko);
	print O "Overall Accuracy ($t): ";
	printf O (" %0.3f\n",$_);
	
	foreach $field (sort keys %Eval) {
	    
	    $ok = $Eval{$field}{ok};
	    $ko = 0;
	    $ko = $Eval{$field}{ko} if defined $Eval{$field}{ko};
	    
	    $_ = $ok / ($ok + $ko);
	    print O "\tAttrib.: $FNames[$field]\; Accuracy: ";
	printf O (" %0.3f\n",$_);
	}
    }
}

sub task2b_fsc {

    my (%Eval,$id,$field,$tp,$fp,$fn,$t,$g,$pr);
    my @T = ("strict","relaxed");

    foreach $t (@T) {
	undef %Eval;

	$tp = 0; $fp = 0; $fn = 0;

	foreach $id (keys %{$H{Gold}}) {    
	    foreach $field (keys %{$H{Pred}{$id}}) {
		
		$g = $H{Gold}{$id}{$field};
		$pr = $H{Pred}{$id}{$field};

		#Gold is default
		if ($g eq "null") {
		    #Pred is not default
		    if ($pr ne "null") {
			$Eval{$field}{fp}++;
			$fp++;
		    }
		}
		#Pred is default
		elsif ($pr eq "null") {
		    $Eval{$field}{fn}++;
		    $fn++;
		}
		elsif ($pr eq $g) {
		    $Eval{$field}{tp}++;
		    $tp++;
		}
		elsif (($t eq "relaxed")&&
		       (&overlap($pr,$g))) {
		    $Eval{$field}{tp}++;
		    $tp++;
		}
		else {
		    $Eval{$field}{fn}++;
		    $fn++;
		    $Eval{$field}{fp}++;
		    $fp++;
		}
	    }
	}
    
	print O "\n\nOverall F-score ($t): ";

	my $p = 0; my $r = 0; my $f = 0;
	if ($tp != 0) {	
	    $p = $tp / ($tp + $fp);
	    $r = $tp / ($tp + $fn);
	    $f = 2 * $p * $r / ($p + $r);
	}
	
	printf O ("P: %0.3f ",$p);
	printf O ("R: %0.3f ",$r);
	printf O ("F-sc: %0.3f\n",$f);
	
	foreach $field (sort keys %Eval) {
	    $tp = 0; $fp = 0; $fn = 0;
	    $tp = $Eval{$field}{tp} if defined $Eval{$field}{tp};
	    $fp = $Eval{$field}{fp} if defined $Eval{$field}{fp};
	    $fn = $Eval{$field}{fn} if defined $Eval{$field}{fn};
	    
	    $p = 0; $r = 0; $f = 0;	
	    if ($tp != 0) {	
		$p = $tp / ($tp + $fp);
		$r = $tp / ($tp + $fn);
		$f = 2 * $p * $r / ($p + $r);
	    }
	    print O "\tAttrib.: $FNames[$field]\; ";
	    printf O ("P: %0.3f ",$p);
	    printf O ("R: %0.3f ",$r);
	    printf O ("F-sc: %0.3f\n",$f);
	}
    }
}

sub overlap {
    my $b1 = $_[0];
    my $b2 = $_[1];

    if (($b1 eq "null")||($b2 eq "null")) {
	return 0;
    }
    my @Pair1 = split(/\-/,$b1);
    my @Pair2 = split(/\-/,$b1);

    if (($Pair2[0] >= $Pair1[1])||($Pair1[0]>=$Pair2[1])) {
	return 0;}
    else {
	return 1;}
}
